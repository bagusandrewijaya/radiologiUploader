<!-- </p> -->
<!-- <p align="center"> -->
<h2 align="center">GTK + Flutter example app</h2>

### How to test
* Run below command in the terminal
```sh
flutter pub get;
cd example;
flutter create .
``` 
* Now test example using `flutter run` or by tapping on the debug icon on your favorite IDE.

