enum ViewSwitcherPolicy { wide, narrow }
