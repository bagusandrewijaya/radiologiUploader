import 'package:flutter/material.dart';

@Deprecated('Use [AdwButton] widget instead')
class AdwTextButton extends StatelessWidget {
  @Deprecated('Use [AdwButton] widget instead')
  // ignore: use_key_in_widget_constructors
  const AdwTextButton();

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
